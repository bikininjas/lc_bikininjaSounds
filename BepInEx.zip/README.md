# Bikininja Sounds

This small project includes custom sounds for a few things in Lethal Company. Those sounds are mostly french memes.

You can find sounds of Emmanuel Macron, Denis Brognart, Marine Le Pen, Sardoche and such

Please note that I dislike all those people but it's fun to integrate them as monsters in the game :)

## Sounds changed

- Bracken : all sounds are from Macron
- Turret : When a turret sees you, it says "AH !" from Denis Brognart
- 